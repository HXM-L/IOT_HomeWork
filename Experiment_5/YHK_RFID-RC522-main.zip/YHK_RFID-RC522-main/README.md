# YHK_RFID-RC522
实现的是Mind+上传模式的第三方Arduino用户库。利用Arduino UNO+RFID-RC522模块读S50卡的UID并从串口输出。
